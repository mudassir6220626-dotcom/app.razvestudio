const express = require('express');
const authMiddleware = require('../middleware/auth');
const Customer = require('../models/Customer');
const router = express.Router();

router.post('/customers', authMiddleware, async (req, res) => {
  const { name, email } = req.body;
  try {
    const customer = await Customer.create({ userId: req.userId, name, email });
    res.status(201).json(customer);
  } catch (error) {
    res.status(400).json({ error: 'Error adding customer' });
  }
});

module.exports = router;