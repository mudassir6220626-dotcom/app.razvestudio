const express = require('express');
const authMiddleware = require('../middleware/auth');
const Expense = require('../models/Expense');
const Sale = require('../models/Sale');
const router = express.Router();

router.get('/financial-report', authMiddleware, async (req, res) => {
  const { startDate, endDate } = req.query;
  const where = { userId: req.userId, date: { [require('sequelize').Op.between]: [new Date(startDate), new Date(endDate)] } };
  const expenses = await Expense.findAll({ where });
  const sales = await Sale.findAll({ where });
  
  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const totalSales = sales.reduce((sum, sale) => sum + sale.amount, 0);
  const profitLoss = totalSales - totalExpenses;
  const taxRate = 0.15; // 15% tax rate
  const tax = profitLoss > 0 ? profitLoss * taxRate : 0;

  res.json({ totalExpenses, totalSales, profitLoss, tax });
});

module.exports = router;