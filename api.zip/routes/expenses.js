const express = require('express');
const authMiddleware = require('../middleware/auth');
const Expense = require('../models/Expense');
const router = express.Router();

router.post('/expenses', authMiddleware, async (req, res) => {
  const { amount, category, description } = req.body;
  try {
    const expense = await Expense.create({
      userId: req.userId,
      amount,
      category,
      description,
    });
    res.status(201).json(expense);
  } catch (error) {
    res.status(400).json({ error: 'Error adding expense' });
  }
});

router.get('/expenses', authMiddleware, async (req, res) => {
  const { startDate, endDate } = req.query;
  const where = { userId: req.userId };
  if (startDate && endDate) {
    where.date = { [require('sequelize').Op.between]: [new Date(startDate), new Date(endDate)] };
  }
  const expenses = await Expense.findAll({ where });
  res.json(expenses);
});

module.exports = router;