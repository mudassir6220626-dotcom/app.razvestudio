const express = require('express');
const authMiddleware = require('../middleware/auth');
const Sale = require('../models/Sale');
const router = express.Router();

router.post('/sales', authMiddleware, async (req, res) => {
  const { amount } = req.body;
  try {
    const sale = await Sale.create({ userId: req.userId, amount });
    res.status(201).json(sale);
  } catch (error) {
    res.status(400).json({ error: 'Error adding sale' });
  }
});

module.exports = router;